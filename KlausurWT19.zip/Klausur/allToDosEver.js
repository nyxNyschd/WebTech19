allToDos = { toDos: [
        ["clean my room", "study for WebTech", "move bauwagen", "water plants"],
        ["clean bathroom", "start internship","tax declaration"]
    ]};